"! <p class="shorttext synchronized">Business Partner Fix Table</p>
"! Table definition for storing Business Partner fixes.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Store field changes for Business Partner data</li>
"! <li>Track old and new values for audit purposes</li>
"! <li>Provide status and messages for each change</li>
"! </ul>
TABLE zbp_bp_fix_fv.

"! <p class="shorttext synchronized">Client field</p>
MANDT TYPE mandt,

"! <p class="shorttext synchronized">Business Partner ID</p>
PARTNER TYPE bu_partner,

"! <p class="shorttext synchronized">Field name</p>
FIELD TYPE string,

"! <p class="shorttext synchronized">Old value</p>
OLD_VALUE TYPE string,

"! <p class="shorttext synchronized">New value</p>
NEW_VALUE TYPE string,

"! <p class="shorttext synchronized">Status</p>
STATUS TYPE char01,

"! <p class="shorttext synchronized">Message</p>
MESSAGE TYPE string,

"! <p class="shorttext synchronized">Created on</p>
ERDAT TYPE sy-datum,

"! <p class="shorttext synchronized">Created at</p>
ERZET TYPE sy-uzeit,

"! <p class="shorttext synchronized">Created by</p>
ERNAM TYPE sy-uname.

"! <p class="shorttext synchronized">Primary key</p>
PRIMARY KEY mandt partner field.

ENDTABLE.