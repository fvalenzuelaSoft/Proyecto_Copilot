"! <p class="shorttext synchronized">DPI (Documento Personal de Identificaci\u00f3n) Validator</p>
"! Validates Guatemalan DPI identification numbers according to RENAP standards.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Validate DPI format (exactly 13 numeric digits)</li>
"! <li>Clean input by removing spaces, hyphens, and dots</li>
"! <li>Propose normalized value when format corrections are needed</li>
"! </ul>
"! <strong>Business Rules:</strong>
"! <ul>
"! <li>Valid DPI must contain exactly 13 consecutive numeric digits</li>
"! <li>Input normalization: remove spaces, hyphens (-), and dots (.)</li>
"! <li>Empty/initial value results in validation error</li>
"! <li>Valid but reformatted value results in warning with proposal</li>
"! <li>Invalid format results in critical error without proposal</li>
"! </ul>
"! <strong>ASSUMPTIONS:</strong>
"! <ul>
"! <li>No CUI (C\u00f3digo \u00danico de Identificaci\u00f3n) checksum validation performed</li>
"! <li>No municipality/department code validation against RENAP catalog</li>
"! <li>Only format validation, not existence verification against external systems</li>
"! </ul>
CLASS zcl_bp_val_dpi_fv DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_bp_validator_fv.
ENDCLASS.



CLASS zcl_bp_val_dpi_fv IMPLEMENTATION.

  METHOD zif_bp_validator_fv~validate.
    " Validates DPI format:
    " 1. Empty check -> Error
    " 2. Clean input (remove spaces, hyphens, dots)
    " 3. Validate 13 consecutive digits via regex
    " 4. Return OK if valid and unchanged, Warning if reformatted, Error if invalid

    IF iv_value IS INITIAL.
      ev_ok       = abap_false.
      ev_proposal = ''.
      ev_message  = 'DPI vac\u00edo o no informado'.
      RETURN.
    ENDIF.

    DATA(lv_original) = iv_value.
    DATA(lv_clean)    = iv_value.

    CONDENSE lv_clean NO-GAPS.
    REPLACE ALL OCCURRENCES OF `-` IN lv_clean WITH ``.
    REPLACE ALL OCCURRENCES OF `.` IN lv_clean WITH ``.

    FIND REGEX '^\\d{13}$' IN lv_clean.

    IF sy-subrc = 0.
      ev_proposal = lv_clean.

      IF lv_original = ev_proposal.
        ev_ok      = abap_true.
        ev_message = 'DPI v\u00e1lido'.
      ELSE.
        ev_ok      = abap_false.
        ev_message = |Se corrigi\u00f3 formato: de \"{ lv_original }\" a \"{ ev_proposal }\"|.
      ENDIF.
    ELSE.
      ev_ok       = abap_false.
      ev_proposal = ''.
      ev_message  = 'DPI inv\u00e1lido. Se esperan exactamente 13 d\u00edgitos num\u00e9ricos'.
    ENDIF.
  ENDMETHOD.

ENDCLASS.