"! <p class="shorttext synchronized">Business Partner Field Updater</p>
"! Applies field corrections to custom Z table for BP audit fixes.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Persist field changes to ZBP_BP_FIX_FV table</li>
"! <li>Handle simulation mode for dry-run testing</li>
"! <li>Manage database commit/rollback for transactional integrity</li>
"! <li>Return BAPIRET2 messages for caller feedback</li>
"! </ul>
"! <strong>ASSUMPTIONS:</strong>
"! <ul>
"! <li>ZBP_BP_FIX_FV table exists with appropriate structure</li>
"! <li>Changes are applied per partner in a single LUW</li>
"! <li>Rollback occurs on any single field update failure</li>
"! </ul>
CLASS zcl_bp_updater_fv DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_bp_updater_fv.
  PRIVATE SECTION.
    "! <p class="shorttext synchronized">Append message to return table</p>
    "! @parameter iv_type | <p class="shorttext synchronized">Message type (S/E/W/I)</p>
    "! @parameter iv_message | <p class="shorttext synchronized">Message text</p>
    "! @parameter ct_return | <p class="shorttext synchronized">Return table to append to</p>
    METHODS add_ret
      IMPORTING
        iv_type    TYPE bapiret2-type
        iv_message TYPE string
      CHANGING
        ct_return  TYPE bapiret2_t.
ENDCLASS.

CLASS zcl_bp_updater_fv IMPLEMENTATION.

  METHOD add_ret.
    " Appends a BAPIRET2 entry to the return table.
    APPEND VALUE bapiret2( type = iv_type message = iv_message ) TO ct_return.
  ENDMETHOD.

  METHOD zif_bp_updater_fv~apply_changes_for_partner.
    " Applies field changes to ZBP_BP_FIX_FV table for a single partner.
    " In simulation mode, returns success messages without database changes.
    " On error, performs rollback and returns failure status.

    ev_success = abap_false.
    DATA lt_return TYPE bapiret2_t.

    IF it_changes IS INITIAL.
      ev_success = abap_true.
      add_ret( EXPORTING iv_type = 'S' iv_message = 'Sin cambios' CHANGING ct_return = lt_return ).
      rt_return = lt_return.
      RETURN.
    ENDIF.

    IF iv_simulation = abap_true.
      LOOP AT it_changes INTO DATA(ls_chg).
        add_ret(
          EXPORTING
            iv_type = 'S'
            iv_message = |SIM(Z): { iv_partner } { ls_chg-field } { ls_chg-old_value } -> { ls_chg-new_value }|
          CHANGING
            ct_return = lt_return
        ).
      ENDLOOP.
      ev_success = abap_true.
      rt_return = lt_return.
      RETURN.
    ENDIF.

    TRY.

        LOOP AT it_changes INTO DATA(ls_change).

          DATA(lv_field) = condense( ls_change-field ).
          TRANSLATE lv_field TO UPPER CASE.

          DATA(ls_db) = VALUE zbp_bp_fix_fv(
            mandt     = sy-mandt
            partner   = iv_partner
            field     = lv_field
            old_value = ls_change-old_value
            new_value = ls_change-new_value
            status    = 'S'
            message   = 'Grabado en tabla Z'
            erdat     = sy-datum
            erzet     = sy-uzeit
            ernam     = sy-uname
          ).

          MODIFY zbp_bp_fix_fv FROM ls_db.
          IF sy-subrc <> 0.
            add_ret( EXPORTING iv_type = 'E'
                     iv_message = |Error al grabar ZBP_BP_FIX_FV: { iv_partner } { lv_field }|
                     CHANGING ct_return = lt_return ).
            ROLLBACK WORK.
            ev_success = abap_false.
            rt_return = lt_return.
            RETURN.
          ENDIF.

          add_ret( EXPORTING iv_type = 'S'
                   iv_message = |OK Z: { iv_partner } { lv_field }|
                   CHANGING ct_return = lt_return ).

        ENDLOOP.

        COMMIT WORK AND WAIT.

        ev_success = abap_true.
        rt_return = lt_return.

      CATCH zcx_bp_audit_fv INTO DATA(lx).
        ROLLBACK WORK.
        add_ret( EXPORTING iv_type = 'E' iv_message = lx->get_text( ) CHANGING ct_return = lt_return ).
        ev_success = abap_false.
        rt_return = lt_return.
    ENDTRY.
  ENDMETHOD.

ENDCLASS.