"! <p class="shorttext synchronized">Business Partner Repository</p>
"! Reads Business Partner data from SAP tables (BUT000, BUT0ID, BUT020, ADR6, ADR2).
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Retrieve BP master data from BUT000</li>
"! <li>Retrieve identification numbers (NIT, DPI) from BUT0ID</li>
"! <li>Retrieve email addresses from ADR6 via BUT020</li>
"! <li>Retrieve phone numbers from ADR2 via BUT020</li>
"! </ul>
"! <strong>ASSUMPTIONS:</strong>
"! <ul>
"! <li>ID type 'GTNIT' for NIT, 'GTDPI' for DPI</li>
"! <li>BP type '1' = Person, '2' = Organization</li>
"! <li>Filter 'P' = Person only, 'O' = Organization only</li>
"! </ul>
CLASS zcl_bp_repo_fv DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES zif_bp_repo_fv.
ENDCLASS.



CLASS ZCL_BP_REPO_FV IMPLEMENTATION.


  METHOD zif_bp_repo_fv~read_bps.

    SELECT partner, type, name_org1, name_first
    FROM but000
    WHERE partner IN @it_partner
    INTO TABLE @DATA(lt_but000).

    IF lt_but000 IS INITIAL.
      RETURN.
    ENDIF.

    CASE iv_bp_type_filter.
      WHEN 'P'.
        DELETE lt_but000 WHERE type <> '1'.
      WHEN 'O'.
        DELETE lt_but000 WHERE type <> '2'.
    ENDCASE.

    IF lt_but000 IS INITIAL.
      RETURN.
    ENDIF.

    SELECT partner, type, idnumber
    FROM but0id
    FOR ALL ENTRIES IN @lt_but000
    WHERE partner = @lt_but000-partner
    INTO TABLE @DATA(lt_but0id).
    SORT lt_but0id BY partner type.

    SELECT b~partner, a~smtp_addr
    FROM but020 AS b
    INNER JOIN adr6 AS a ON a~addrnumber = b~addrnumber
    FOR ALL ENTRIES IN @lt_but000
    WHERE b~partner = @lt_but000-partner
    INTO TABLE @DATA(lt_email).

    SELECT b~partner, a~tel_number
    FROM but020 AS b
    INNER JOIN adr2 AS a ON a~addrnumber = b~addrnumber
    FOR ALL ENTRIES IN @lt_but000
    WHERE b~partner = @lt_but000-partner
    INTO TABLE @DATA(lt_phone).

    SORT lt_email BY partner.
    SORT lt_phone BY partner.

    rt_bp = VALUE zif_bp_repo_fv=>tt_bp_raw(
      FOR ls IN lt_but000
      LET lv_nit = COND string(
            WHEN line_exists( lt_but0id[ partner = ls-partner type = 'GTNIT' ] )
            THEN lt_but0id[ partner = ls-partner type = 'GTNIT' ]-idnumber ELSE '' )
          lv_dpi = COND string(
            WHEN line_exists( lt_but0id[ partner = ls-partner type = 'GTDPI' ] )
            THEN lt_but0id[ partner = ls-partner type = 'GTDPI' ]-idnumber ELSE '' )
          lv_eml = COND string(
            WHEN line_exists( lt_email[ partner = ls-partner ] )
            THEN lt_email[ partner = ls-partner ]-smtp_addr ELSE '' )
          lv_tel = COND string(
            WHEN line_exists( lt_phone[ partner = ls-partner ] )
            THEN lt_phone[ partner = ls-partner ]-tel_number ELSE '' )
      IN ( partner  = ls-partner
           bp_type  = ls-type
           name_org = ls-name_org1
           name_per = ls-name_first
           id_nit   = lv_nit
           id_dpi   = lv_dpi
           email    = lv_eml
           phone    = lv_tel )
    ).

  ENDMETHOD.
ENDCLASS.