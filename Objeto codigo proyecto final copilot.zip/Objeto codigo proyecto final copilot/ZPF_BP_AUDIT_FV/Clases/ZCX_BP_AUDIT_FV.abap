"! <p class="shorttext synchronized">Business Partner Audit Exception</p>
"! Custom exception for BP audit system errors.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Provide custom exception for BP audit operations</li>
"! <li>Store and retrieve error message text</li>
"! <li>Support exception chaining via previous parameter</li>
"! </ul>
"! <strong>ASSUMPTIONS:</strong>
"! <ul>
"! <li>Inherits from cx_static_check for mandatory handling</li>
"! <li>Default message used when none provided</li>
"! <li>Immutable text via READ-ONLY attribute</li>
"! </ul>
CLASS zcx_bp_audit_fv DEFINITION
  PUBLIC
  INHERITING FROM cx_static_check
  CREATE PUBLIC.
  PUBLIC SECTION.
    "! <p class="shorttext synchronized">Error message text</p>
    DATA mv_text TYPE string READ-ONLY.

    "! <p class="shorttext synchronized">Constructor</p>
    "! @parameter iv_text | <p class="shorttext synchronized">Custom error message</p>
    "! @parameter previous | <p class="shorttext synchronized">Previous exception for chaining</p>
    METHODS constructor
      IMPORTING
        iv_text  TYPE string OPTIONAL
        previous TYPE REF TO cx_root OPTIONAL.

    "! <p class="shorttext synchronized">Get exception text</p>
    "! @parameter result | <p class="shorttext synchronized">Error message</p>
    METHODS get_text REDEFINITION.
ENDCLASS.

CLASS zcx_bp_audit_fv IMPLEMENTATION.

  METHOD constructor ##ADT_SUPPRESS_GENERATION.
    " Calls parent constructor and sets error text.
    " Uses default message if none provided.
    super->constructor( previous = previous ).
    mv_text = COND #( WHEN iv_text IS NOT INITIAL THEN iv_text
                      ELSE 'Error en sistema de auditor\u00eda BP' ).
  ENDMETHOD.

  METHOD get_text.
    " Returns the stored error message text.
    result = mv_text.
  ENDMETHOD.

ENDCLASS.