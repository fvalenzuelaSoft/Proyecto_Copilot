"! <p class="shorttext synchronized">Business Partner Updater Interface</p>
"! Interface for updating Business Partner data.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Apply field changes to Business Partner data</li>
"! <li>Handle simulation mode for testing changes</li>
"! </ul>
INTERFACE zif_bp_updater_fv PUBLIC.
  METHODS apply_changes_for_partner
    IMPORTING
      iv_partner   TYPE bu_partner
      it_changes   TYPE TABLE OF zbp_bp_change
      iv_simulation TYPE abap_bool
    EXPORTING
      ev_success   TYPE abap_bool
      rt_return    TYPE bapiret2_t.
ENDINTERFACE.