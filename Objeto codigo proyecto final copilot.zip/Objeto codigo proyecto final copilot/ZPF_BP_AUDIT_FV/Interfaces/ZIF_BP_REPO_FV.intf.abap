"! <p class="shorttext synchronized">Business Partner Repository Interface</p>
"! Interface for accessing Business Partner data.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Retrieve Business Partner master data</li>
"! <li>Retrieve identification numbers</li>
"! <li>Retrieve contact information</li>
"! </ul>
INTERFACE zif_bp_repo_fv PUBLIC.
  METHODS read_bps
    IMPORTING
      it_partner        TYPE STANDARD TABLE OF bu_partner
      iv_bp_type_filter TYPE char01
    EXPORTING
      rt_bp             TYPE TABLE OF zbp_bp_raw.
ENDINTERFACE.