"! <p class="shorttext synchronized">Business Partner Validator Interface</p>
"! Interface for validating Business Partner data.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Validate Business Partner fields</li>
"! <li>Provide validation results and proposals</li>
"! </ul>
INTERFACE zif_bp_validator_fv PUBLIC.
  METHODS validate
    IMPORTING
      iv_value    TYPE string
    EXPORTING
      ev_ok       TYPE abap_bool
      ev_proposal TYPE string
      ev_message  TYPE string.
ENDINTERFACE.