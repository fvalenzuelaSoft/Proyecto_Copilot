"! <p class="shorttext synchronized">Audit Log Interface</p>
"! Interface for managing audit logs in Business Partner processing.
"! <br/>
"! <strong>Responsibilities:</strong>
"! <ul>
"! <li>Add log entries</li>
"! <li>Flush logs to persistent storage</li>
"! </ul>
INTERFACE zif_bp_audit_log_fv PUBLIC.
  METHODS add
    IMPORTING
      iv_partner TYPE bu_partner
      iv_level   TYPE char01
      iv_text    TYPE string.

  METHODS flush.
ENDINTERFACE.